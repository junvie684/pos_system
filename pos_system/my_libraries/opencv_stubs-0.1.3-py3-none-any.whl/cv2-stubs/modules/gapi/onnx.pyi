from typing import Any, Final

from typing_extensions import TypeAlias

retval: TypeAlias = Any

class PyParams: ...

def params(tag, model_path) -> retval:
    """
    .
    """

TRAIT_AS_IMAGE: Final[int]
TRAIT_AS_TENSOR: Final[int]
TraitAs_IMAGE: Final[int]
TraitAs_TENSOR: Final[int]
